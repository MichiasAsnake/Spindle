// content.js - Runs on the job list page

console.log('Decopress PMS Indicator content script loaded - START');

// Create a mapping of job IDs to their PMS status
const pmsJobStatus = {};

// Function to add a PMS column to the job list table
function addPmsColumn() {
  console.log('Adding PMS column to job list');
  
  // Find the table header row - using the actual structure from the page
  const headerRow = document.querySelector('table.data-results thead tr');
  if (!headerRow) {
    console.error('Could not find job list header row');
    
    // Try to find any table headers to help debug
    const allHeaders = document.querySelectorAll('th');
    console.log('Found ' + allHeaders.length + ' table headers on page');
    allHeaders.forEach((header, index) => {
      console.log(`Header ${index}: ${header.textContent}`);
    });
    
    return;
  }
  
  console.log('Found job list header:', headerRow);
  
  // Create a new header cell for PMS status
  const pmsHeaderCell = document.createElement('th');
  pmsHeaderCell.className = 'pms-status-header';
  pmsHeaderCell.textContent = 'PMS';
  pmsHeaderCell.style.width = '40px';
  
  // Insert the new header cell after the Description column
  const descriptionHeader = headerRow.querySelector('th[id="sortDescription"]');
  if (descriptionHeader) {
    descriptionHeader.insertAdjacentElement('afterend', pmsHeaderCell);
    console.log('Added PMS header cell after Description column');
  } else {
    // Fallback: insert before the last cell
    headerRow.insertBefore(pmsHeaderCell, headerRow.lastElementChild);
    console.log('Added PMS header cell before last column');
  }
  
  // Find all job rows and add PMS status cells
  const jobRows = document.querySelectorAll('tr.js-jobstatus-row');
  console.log(`Found ${jobRows.length} job rows`);
  
  jobRows.forEach((row, index) => {
    console.log(`Adding PMS cell to row ${index}`);
    addPmsCellToRow(row);
  });
  
  // Add PMS filter to the filter panel
  addPmsFilter();
}

// Function to add a PMS filter to the filter panel
function addPmsFilter() {
  console.log('Adding PMS filter to filter panel');
  
  // Find the Process filter section
  const processFilterSection = document.querySelector('li:has(#processFilter)');
  if (!processFilterSection) {
    console.error('Could not find process filter section');
    return;
  }
  
  // Create a new filter section for PMS
  const pmsFilterSection = document.createElement('li');
  pmsFilterSection.className = 'pr-2 cw-collapsible';
  pmsFilterSection.innerHTML = `
    <h4>PMS Colors</h4>
    <ul id="pmsFilter" class="js-toggle-button-group btn-group-toggle d-flex flex-wrap m-0 p-0" data-toggle="buttons">
      <li class="m-0 pb-1">
        <label class="btn btn-secondary active">
          <input type="checkbox" value="ALL" data-code="ALL" data-for="pms-filter" checked="checked">All
        </label>
      </li>
      <li class="m-0 pb-1">
        <label class="btn btn-secondary">
          <input type="checkbox" value="YES" name="pms-filter" id="pmsFilter_1" data-toggle-group="true">Has PMS
        </label>
      </li>
      <li class="m-0 pb-1">
        <label class="btn btn-secondary">
          <input type="checkbox" value="NO" name="pms-filter" id="pmsFilter_2" data-toggle-group="true">No PMS
        </label>
      </li>
    </ul>
  `;
  
  // Insert the new filter section after the Process filter section
  processFilterSection.insertAdjacentElement('afterend', pmsFilterSection);
  console.log('Added PMS filter section');
  
  // Add event listeners to the PMS filter buttons
  const pmsFilterButtons = pmsFilterSection.querySelectorAll('input[name="pms-filter"]');
  pmsFilterButtons.forEach(button => {
    button.addEventListener('change', function() {
      filterJobsByPmsStatus(this.value);
    });
  });
  
  // Add event listener to the "All" button
  const pmsFilterAllButton = pmsFilterSection.querySelector('input[data-for="pms-filter"]');
  if (pmsFilterAllButton) {
    pmsFilterAllButton.addEventListener('change', function() {
      if (this.checked) {
        showAllJobs();
      }
    });
  }
}

// Function to filter jobs by PMS status
function filterJobsByPmsStatus(filterValue) {
  console.log(`Filtering jobs by PMS status: ${filterValue}`);
  
  // Store the current filter value in a global variable
  window.currentPmsFilter = filterValue;
  
  // First, try to use the website's own filtering mechanism
  const customEvent = new CustomEvent('cw:filter-change', {
    detail: {
      filter: 'pms-filter',
      value: filterValue
    },
    bubbles: true
  });
  
  document.dispatchEvent(customEvent);
  
  // Also apply our own filtering as a fallback
  applyPmsFilterDirectly(filterValue);
  
  // Add a global class to the body to indicate filtering is active
  if (filterValue === 'YES') {
    document.body.classList.add('pms-filter-yes');
    document.body.classList.remove('pms-filter-no');
  } else if (filterValue === 'NO') {
    document.body.classList.add('pms-filter-no');
    document.body.classList.remove('pms-filter-yes');
  } else {
    document.body.classList.remove('pms-filter-yes');
    document.body.classList.remove('pms-filter-no');
  }
  
  // Update the UI to show the active filter
  updateFilterUI(filterValue);
}

// Function to directly apply filtering to all job rows
function applyPmsFilterDirectly(filterValue) {
  // If no filter value is provided, use the stored one
  if (!filterValue && window.currentPmsFilter) {
    filterValue = window.currentPmsFilter;
  }
  
  // If no filter value is available, show all jobs
  if (!filterValue || filterValue === 'ALL') {
    showAllJobs();
    return;
  }
  
  console.log(`Directly applying PMS filter: ${filterValue}`);
  
  // Find all job rows
  const jobRows = document.querySelectorAll('tr.js-jobstatus-row');
  console.log(`Found ${jobRows.length} rows to filter`);
  
  jobRows.forEach(row => {
    const jobId = row.getAttribute('data-jobnumber');
    const pmsCell = row.querySelector(`.pms-status-cell[data-job-id="${jobId}"]`);
    
    if (pmsCell) {
      const hasPms = pmsCell.classList.contains('has-pms');
      
      if (filterValue === 'YES' && !hasPms) {
        row.style.display = 'none';
        row.classList.add('pms-filtered-out');
      } else if (filterValue === 'NO' && hasPms) {
        row.style.display = 'none';
        row.classList.add('pms-filtered-out');
      } else {
        row.style.display = '';
        row.classList.remove('pms-filtered-out');
      }
    }
  });
}

// Function to update the filter UI to highlight the active filter
function updateFilterUI(filterValue) {
  // Find all filter buttons
  const allButton = document.querySelector('input[data-for="pms-filter"]');
  const yesButton = document.querySelector('#pmsFilter_1');
  const noButton = document.querySelector('#pmsFilter_2');
  
  if (allButton && yesButton && noButton) {
    // Reset all buttons
    allButton.checked = false;
    yesButton.checked = false;
    noButton.checked = false;
    
    // Set the active button
    if (filterValue === 'ALL' || !filterValue) {
      allButton.checked = true;
    } else if (filterValue === 'YES') {
      yesButton.checked = true;
    } else if (filterValue === 'NO') {
      noButton.checked = true;
    }
    
    // Update parent label classes
    document.querySelectorAll('#pmsFilter label').forEach(label => {
      label.classList.remove('active');
    });
    
    // Add active class to the selected button's label
    if (filterValue === 'ALL' || !filterValue) {
      allButton.closest('label').classList.add('active');
    } else if (filterValue === 'YES') {
      yesButton.closest('label').classList.add('active');
    } else if (filterValue === 'NO') {
      noButton.closest('label').classList.add('active');
    }
  }
}

// Function to show all jobs (reset filter)
function showAllJobs() {
  console.log('Showing all jobs');
  
  window.currentPmsFilter = 'ALL';
  
  const jobRows = document.querySelectorAll('tr.js-jobstatus-row');
  jobRows.forEach(row => {
    row.style.display = '';
  });
  
  // Update the UI to show the active filter
  updateFilterUI('ALL');
  
  // Remove filtering classes from body
  document.body.classList.remove('pms-filter-yes');
  document.body.classList.remove('pms-filter-no');
}

// Function to add a PMS status cell to a job row
function addPmsCellToRow(row) {
  // Get the job ID from the row
  const jobId = row.getAttribute('data-jobnumber');
  if (!jobId) {
    console.error('Row is missing data-jobnumber attribute:', row);
    return;
  }
  
  console.log(`Adding PMS cell for job ID: ${jobId}`);
  
  // Create a new cell for PMS status
  const pmsCell = document.createElement('td');
  pmsCell.className = 'pms-status-cell';
  pmsCell.setAttribute('data-job-id', jobId);
  
  // Set initial content (loading indicator)
  pmsCell.innerHTML = '<span class="pms-loading">⏳</span>';
  
  // Find the Description cell to insert after
  const cells = row.querySelectorAll('td');
  if (cells.length >= 3) {
    // Insert after the third cell (Description)
    cells[2].insertAdjacentElement('afterend', pmsCell);
  } else {
    // Fallback: insert before the last cell
    row.insertBefore(pmsCell, row.lastElementChild);
  }
  
  // Check if we have the PMS status in memory
  if (pmsJobStatus[jobId] !== undefined) {
    console.log(`Using cached PMS status for job ${jobId}: ${pmsJobStatus[jobId]}`);
    updatePmsCellStatus(pmsCell, pmsJobStatus[jobId]);
  } else {
    // Request PMS status from background script
    console.log(`Requesting PMS status for job ${jobId} from background`);
    chrome.runtime.sendMessage(
      { action: "getJobPmsStatus", jobId: jobId },
      response => {
        console.log(`Received PMS status for job ${jobId}:`, response);
        // Store the response in our mapping
        pmsJobStatus[jobId] = response.hasPms;
        // Update the cell with the status
        updatePmsCellStatus(pmsCell, response.hasPms);
      }
    );
  }
}

// Function to update a PMS status cell with the appropriate indicator
function updatePmsCellStatus(cell, hasPms) {
  console.log(`Updating cell status: hasPms=${hasPms}`);
  
  // Remove any existing classes
  cell.classList.remove('has-pms', 'no-pms');
  
  if (hasPms) {
    cell.innerHTML = '<span class="pms-yes">✅</span>';
    cell.title = 'Contains PMS colors';
    cell.classList.add('has-pms');
  } else {
    cell.innerHTML = '<span class="pms-no">❌</span>';
    cell.title = 'No PMS colors';
    cell.classList.add('no-pms');
  }
}

// Function to check for job rows that need PMS cells
function checkForNewJobRows() {
  console.log('Checking for new job rows');
  const jobRows = document.querySelectorAll('tr.js-jobstatus-row');
  console.log(`Found ${jobRows.length} total job rows`);
  
  let newRowCount = 0;
  jobRows.forEach(row => {
    // Check if this row already has a PMS cell
    const jobId = row.getAttribute('data-jobnumber');
    const existingPmsCell = row.querySelector(`.pms-status-cell[data-job-id="${jobId}"]`);
    
    if (!existingPmsCell) {
      console.log(`Found new row for job ${jobId}`);
      addPmsCellToRow(row);
      newRowCount++;
    }
  });
  
  console.log(`Added PMS cells to ${newRowCount} new rows`);
  
  // If there were new rows added, or if we're checking after a page update, reapply the filter
  if (newRowCount > 0 || window.justUpdated) {
    window.justUpdated = false;
    // Slight delay to let the PMS cells finish updating
    setTimeout(() => {
      if (window.currentPmsFilter) {
        applyPmsFilterDirectly(window.currentPmsFilter);
      }
    }, 100);
  }
}

// Function to handle job detail page
function handleJobDetailPage() {
  console.log('Handling job detail page');
  
  // Check if we're on a job detail page
  const jobIdMatch = window.location.href.match(/[?&]ID=(\d+)/i);
  if (!jobIdMatch) {
    console.error('Could not extract job ID from URL:', window.location.href);
    return;
  }
  
  const jobId = jobIdMatch[1];
  console.log(`Detected job detail page for job ID: ${jobId}`);
  
  // Look for PMS colors in job lines
  const jobLines = document.querySelectorAll('.js-jobline-row');
  console.log(`Found ${jobLines.length} job lines`);
  
  let hasPms = false;
  
  // Enhanced PMS detection - check in comments, descriptions, and additional fields
  // Also check for common PMS color naming patterns like "PMS 123", "Pantone 456", etc.
  
  // 1. First check job lines
  jobLines.forEach((row, index) => {
    // Check in comment field
    const comment = row.getAttribute('data-comment') || '';
    // Check in description fields
    const description = row.querySelector('.job-line-description')?.textContent || '';
    // Check in other cells that might contain text
    const allText = Array.from(row.querySelectorAll('td')).map(td => td.textContent.trim()).join(' ');
    
    console.log(`Job line ${index} - Checking: "${comment}" and "${description}"`);
    
    const combinedText = `${comment} ${description} ${allText}`.toLowerCase();
    
    // Define patterns that indicate PMS colors
    const pmsPatterns = [
      /pms\s*\d+/i,                  // PMS followed by numbers (PMS 123)
      /pantone\s*\d+/i,              // Pantone followed by numbers
      /spot\s*colou?r/i,             // Spot color/colour
      /pms\s*[a-z]+\s*\d+/i,         // PMS with color name and number (PMS Blue 072)
      /pantone\s*[a-z]+\s*\d+/i      // Pantone with color name and number
    ];
    
    // Exclusion patterns (when these appear alone, they often mean no PMS)
    const exclusionPatterns = [
      /no\s*pms/i,
      /without\s*pms/i,
      /no\s*pantone/i,
      /no\s*spot/i
    ];
    
    // Check for positive patterns
    const hasPmsPattern = pmsPatterns.some(pattern => pattern.test(combinedText));
    
    // Check for exclusion patterns
    const hasExclusionPattern = exclusionPatterns.some(pattern => pattern.test(combinedText));
    
    // If it matches a PMS pattern and doesn't have an exclusion pattern
    if (hasPmsPattern && !hasExclusionPattern) {
      console.log(`Found PMS color in job line ${index}: "${combinedText.substring(0, 100)}..."`);
      hasPms = true;
    }
    
    // Also try simple string matching which was working before
    if (combinedText.includes('pms') && !combinedText.includes('no pms')) {
      console.log(`Found PMS color in job line ${index} using simple string match`);
      hasPms = true;
    }
  });
  
  // 2. Check in the overall job details and specs section
  const jobDetails = document.querySelector('.job-details-container, .job-details, .job-specs');
  if (jobDetails) {
    const detailsText = jobDetails.textContent.toLowerCase();
    
    // Look for PMS indicators in job details
    if (
      (detailsText.includes('pms') || 
       detailsText.includes('pantone') || 
       detailsText.includes('spot color') || 
       detailsText.includes('spot colour')) && 
      !detailsText.includes('no pms') && 
      !detailsText.includes('without pms')
    ) {
      console.log('Found PMS color indicator in job details');
      hasPms = true;
    }
  }
  
  console.log(`Job ${jobId} PMS status: ${hasPms}`);
  
  // Update the PMS status in storage
  chrome.runtime.sendMessage(
    { action: "updateJobPmsStatus", jobId: jobId, hasPms: hasPms },
    response => {
      console.log(`Updated PMS status for job ${jobId} in storage:`, response);
    }
  );
  
  // Add a visual indicator to the job page
  const jobHeader = document.querySelector('.job-header');
  if (jobHeader) {
    console.log('Found job header, adding PMS indicator');
    
    // Check if an indicator already exists
    let pmsIndicator = jobHeader.querySelector('.pms-indicator');
    if (!pmsIndicator) {
      pmsIndicator = document.createElement('div');
      pmsIndicator.className = 'pms-indicator';
      jobHeader.appendChild(pmsIndicator);
    }
    
    pmsIndicator.innerHTML = hasPms ? 
      '<span class="pms-yes">✅ PMS Colors</span>' : 
      '<span class="pms-no">❌ No PMS Colors</span>';
  } else {
    console.error('Could not find job header (.job-header)');
    
    // Try to find alternative elements to attach the indicator
    const h1Elements = document.querySelectorAll('h1');
    console.log(`Found ${h1Elements.length} h1 elements on page`);
    
    if (h1Elements.length > 0) {
      console.log('Attaching PMS indicator to first h1 element');
      
      // Check if an indicator already exists
      let pmsIndicator = h1Elements[0].querySelector('.pms-indicator');
      if (!pmsIndicator) {
        pmsIndicator = document.createElement('div');
        pmsIndicator.className = 'pms-indicator';
        h1Elements[0].appendChild(pmsIndicator);
      }
      
      pmsIndicator.innerHTML = hasPms ? 
        '<span class="pms-yes">✅ PMS Colors</span>' : 
        '<span class="pms-no">❌ No PMS Colors</span>';
    }
  }
}

// Main initialization
function init() {
  console.log('Decopress PMS Indicator content script init');
  console.log('Current URL:', window.location.href);
  
  // Create a global variable to keep track of whether we just updated the page
  window.justUpdated = false;
  
  // Check if we're on the job list page or job detail page
  if (window.location.href.includes('JobStatusList.aspx')) {
    console.log('Detected job list page');
    
    // Wait a bit for the page to fully render
    setTimeout(() => {
      // We're on the job list page
      addPmsColumn();
      
      // Set up a mutation observer to detect new job rows
      console.log('Setting up mutation observer');
      const observer = new MutationObserver((mutations) => {
        console.log('Mutation detected:', mutations.length, 'changes');
        window.justUpdated = true;
        checkForNewJobRows();
      });
      
      // Start observing the table for changes
      const jobTable = document.querySelector('table.data-results');
      if (jobTable) {
        console.log('Found job table, starting observation');
        observer.observe(jobTable, { childList: true, subtree: true });
      } else {
        console.error('Could not find job table');
        
        // Log the body HTML to help debug
        console.log('Page body structure:');
        console.log(document.body.innerHTML.substring(0, 500) + '...');
      }
      
      // Listen for the website's search/filter events
      document.addEventListener('cw:search', () => {
        console.log('Detected cw:search event');
        window.justUpdated = true;
        
        // Wait a bit for the table to update
        setTimeout(() => {
          // Re-add PMS cells to any new rows
          checkForNewJobRows();
          
          // Force reapply the current filter if one is active
          if (window.currentPmsFilter) {
            applyPmsFilterDirectly(window.currentPmsFilter);
          }
        }, 500);
      });
      
      // Also check for the filter-changed event
      document.addEventListener('cw:filter-changed', (event) => {
        console.log('Detected cw:filter-changed event:', event);
        window.justUpdated = true;
        
        // Wait a bit for the table to update
        setTimeout(() => {
          if (window.currentPmsFilter) {
            applyPmsFilterDirectly(window.currentPmsFilter);
          }
        }, 500);
      });
      
      // Also check for changes when page loads or user navigates
      window.addEventListener('load', () => {
        console.log('Page load event detected');
        window.justUpdated = true;
        setTimeout(() => {
          checkForNewJobRows();
          if (window.currentPmsFilter) {
            applyPmsFilterDirectly(window.currentPmsFilter);
          }
        }, 500);
      });
      
      // If browser navigation happens (back/forward)
      window.addEventListener('popstate', () => {
        console.log('Navigation event detected');
        window.justUpdated = true;
        setTimeout(() => {
          checkForNewJobRows();
          if (window.currentPmsFilter) {
            applyPmsFilterDirectly(window.currentPmsFilter);
          }
        }, 500);
      });
      
      // Create a periodic check to ensure filtering is applied
      setInterval(() => {
        if (window.currentPmsFilter) {
          // Check if all rows are correctly filtered
          const jobRows = document.querySelectorAll('tr.js-jobstatus-row');
          let needsRefilter = false;
          
          jobRows.forEach(row => {
            const jobId = row.getAttribute('data-jobnumber');
            const pmsCell = row.querySelector(`.pms-status-cell[data-job-id="${jobId}"]`);
            
            if (pmsCell) {
              const hasPms = pmsCell.classList.contains('has-pms');
              const isFiltered = row.classList.contains('pms-filtered-out');
              
              if ((window.currentPmsFilter === 'YES' && !hasPms && !isFiltered) ||
                  (window.currentPmsFilter === 'NO' && hasPms && !isFiltered)) {
                needsRefilter = true;
              }
            }
          });
          
          if (needsRefilter) {
            console.log('Found incorrectly filtered rows, reapplying filter');
            applyPmsFilterDirectly(window.currentPmsFilter);
          }
        }
      }, 2000); // Check every 2 seconds
      
    }, 1000); // Wait 1 second for the page to load
    
  } else if (window.location.href.includes('job.aspx')) {
    console.log('Detected job detail page');
    // We're on a job detail page
    setTimeout(() => {
      handleJobDetailPage();
    }, 1000); // Wait 1 second for the page to load
  } else {
    console.log('Not on a recognized page');
  }
}

// Run initialization when the page is loaded
if (document.readyState === 'loading') {
  console.log('Document still loading, adding DOMContentLoaded listener');
  document.addEventListener('DOMContentLoaded', init);
} else {
  console.log('Document already loaded, running init immediately');
  init();
}

console.log('Decopress PMS Indicator content script loaded - END'); 