// config.js - Configuration for the extension

// Supabase credentials
const SUPABASE_URL = 'https://ruqvuwjgzjinnopjbbfp.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ1cXZ1d2pnemppbm5vcGpiYmZwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc0NTMxNzYsImV4cCI6MjA2MzAyOTE3Nn0.UvzezWVaa53CIQiCN8swVdSHv3JUXOSH3ZZrTRRSbd0';